import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { Face3D } from './Face3D';

export function Logo3D() {
  return (
    <div className="w-32 h-32">
      <Canvas camera={{ position: [0, 0, 4], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <Face3D />
        <OrbitControls enableZoom={false} />
      </Canvas>
    </div>
  );
}