import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sphere, Box } from '@react-three/drei';
import type { Mesh } from 'three';

export function Face3D() {
  const faceRef = useRef<Mesh>(null);
  
  useFrame((state) => {
    if (faceRef.current) {
      faceRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * 0.3;
    }
  });

  return (
    <group ref={faceRef}>
      {/* Head */}
      <Sphere args={[1, 32, 32]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#f0f0f0" />
      </Sphere>
      
      {/* Mask */}
      <Box args={[1.4, 0.8, 0.3]} position={[0, -0.1, 0.6]}>
        <meshStandardMaterial color="#4299e1" />
      </Box>
      
      {/* Eyes */}
      <Sphere args={[0.15, 16, 16]} position={[-0.3, 0.2, 0.85]}>
        <meshStandardMaterial color="#1a365d" />
      </Sphere>
      <Sphere args={[0.15, 16, 16]} position={[0.3, 0.2, 0.85]}>
        <meshStandardMaterial color="#1a365d" />
      </Sphere>
    </group>
  );
}