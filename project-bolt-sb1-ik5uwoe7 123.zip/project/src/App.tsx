import React, { useState, useRef } from 'react';
import { Camera, SwitchCamera, UserCheck, UserX, X } from 'lucide-react';
import { Logo3D } from './components/Logo3D';

function App() {
  const [referenceImages, setReferenceImages] = useState<string[]>([]);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [matchResult, setMatchResult] = useState<boolean | null>(null);
  const [isCameraMode, setIsCameraMode] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setReferenceImages(prev => [...prev, reader.result as string]);
          setCapturedImage(null);
          setMatchResult(null);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeReferenceImage = (index: number) => {
    setReferenceImages(prev => prev.filter((_, i) => i !== index));
    setMatchResult(null);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const toggleMode = () => {
    setIsCameraMode(!isCameraMode);
    if (!isCameraMode) {
      startCamera();
    } else {
      stopCamera();
    }
    setCapturedImage(null);
    setMatchResult(null);
  };

  const captureImage = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg');
        setCapturedImage(imageData);
        setIsProcessing(true);
        
        // Simulate processing against all reference images
        setTimeout(() => {
          setIsProcessing(false);
          setResult('Mask detected');
          // Simulate matching against multiple reference images
          const hasMatch = referenceImages.some(() => Math.random() > 0.3);
          setMatchResult(hasMatch);
        }, 2000);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-600 to-blue-400 relative">
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1584634731339-252c581abfc5?auto=format&fit=crop&w=1920')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          mixBlendMode: 'overlay'
        }}
      />
      
      <div className="relative container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-white/90 p-4 rounded-full shadow-lg backdrop-blur-sm">
              <Logo3D />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Face Mask Detection System
          </h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Advanced facial recognition system for mask detection and identity verification
          </p>
        </header>

        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Reference Images Section */}
            <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden">
              <div className="p-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Reference Images</h2>
                <div className="space-y-4">
                  {/* Image Grid */}
                  {referenceImages.length > 0 && (
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      {referenceImages.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`Reference ${index + 1}`}
                            className="w-full h-40 object-cover rounded-lg"
                          />
                          <button
                            onClick={() => removeReferenceImage(index)}
                            className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Upload Area */}
                  <label
                    htmlFor="image-upload"
                    className="flex flex-col items-center justify-center w-full h-40 border-3 border-dashed border-blue-300 rounded-xl cursor-pointer bg-blue-50/50 hover:bg-blue-50/80 transition-all duration-300"
                  >
                    <div className="flex flex-col items-center justify-center p-6 text-center">
                      <Camera className="w-12 h-12 text-blue-500 mb-4" />
                      <p className="text-lg font-semibold text-gray-700 mb-2">
                        Add Reference Photos
                      </p>
                      <p className="text-sm text-gray-500">
                        Upload multiple photos for better identification
                      </p>
                    </div>
                    <input
                      id="image-upload"
                      type="file"
                      className="hidden"
                      accept="image/*"
                      multiple
                      onChange={handleImageUpload}
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Camera Section */}
            <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden">
              <div className="p-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Live Detection</h2>
                <div className="relative h-72 bg-gray-900 rounded-xl overflow-hidden">
                  {isCameraMode ? (
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Camera className="w-16 h-16 text-gray-600" />
                    </div>
                  )}
                  {capturedImage && (
                    <img
                      src={capturedImage}
                      alt="Captured"
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                  )}
                </div>
                <div className="mt-6 flex justify-center gap-4">
                  <button
                    onClick={toggleMode}
                    className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
                  >
                    <SwitchCamera className="w-5 h-5" />
                    {isCameraMode ? 'Stop Camera' : 'Start Camera'}
                  </button>
                  {isCameraMode && (
                    <button
                      onClick={captureImage}
                      className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-300 shadow-lg hover:shadow-xl"
                      disabled={referenceImages.length === 0}
                    >
                      <Camera className="w-5 h-5" />
                      Capture
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="mt-8 bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden">
            <div className="p-8">
              {isProcessing ? (
                <div className="text-center p-6 bg-blue-50 rounded-xl">
                  <div className="animate-spin w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4" />
                  <p className="text-lg text-blue-800 font-medium">Analyzing image against reference photos...</p>
                </div>
              ) : (
                <>
                  {(result || matchResult !== null) && (
                    <div className="space-y-4">
                      {result && (
                        <div className="text-center p-6 bg-green-50 rounded-xl">
                          <Camera className="w-12 h-12 text-green-600 mx-auto mb-2" />
                          <p className="text-lg text-green-800 font-medium">{result}</p>
                        </div>
                      )}
                      {matchResult !== null && capturedImage && referenceImages.length > 0 && (
                        <div className={`text-center p-6 ${matchResult ? 'bg-green-50' : 'bg-red-50'} rounded-xl`}>
                          {matchResult ? (
                            <>
                              <UserCheck className="w-12 h-12 text-green-600 mx-auto mb-2" />
                              <p className="text-lg text-green-800 font-medium">Identity Match Found</p>
                            </>
                          ) : (
                            <>
                              <UserX className="w-12 h-12 text-red-600 mx-auto mb-2" />
                              <p className="text-lg text-red-800 font-medium">No Identity Match Found</p>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;